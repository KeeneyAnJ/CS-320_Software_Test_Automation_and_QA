/*
 * Andrew Keeney
 * 11/27/2023
 * 6-1 Project One
 * CS-320
 */

package contact;

public class Contact {
	//contact attributes
	private String contactId;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	//Constructor
	public Contact(String contactId, String firstName,
			String lastName, String phone, String address) {
		if(contactId == null || contactId.length()>10) {
			throw new IllegalArgumentException("Invalid contactId");
		}
		if(firstName == null || firstName.length()>10) {
			throw new IllegalArgumentException("Invalid firstName");
		}
		if(lastName == null || lastName.length()>10) {
			throw new IllegalArgumentException("Invalid lastName");
		}
		if(phone == null || phone.length()!=10) {
			throw new IllegalArgumentException("Invalid phone");
		}
		if(address == null || address.length()>30) {
			throw new IllegalArgumentException("Invalid address");
		}
		
		this.contactId = contactId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.address = address;
	}
	
	//Getters:
	public String getContactId() {
		return contactId;
	}
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public String getPhone() {
		return phone;
	}
	public String getAddress() {
		return address;
	}
	
	//Setters: 
	//Used by ContactService. Note there is no way to set the
	//ContactID after creation, making it not updatable.
	
	public void setFirstName(String fName) {
		if(fName == null || fName.length()>10) {
			throw new IllegalArgumentException("Invalid firstName");
		}
		this.firstName = fName;
	}
	
	public void setLastName(String lName) {
		if(lName == null || lName.length()>10) {
			throw new IllegalArgumentException("Invalid firstName");
		}
		this.lastName = lName;
	}
	
	public void setPhone(String pNumber) {
		if(pNumber == null || pNumber.length()!=10) {
			throw new IllegalArgumentException("Invalid firstName");
		}
		this.phone = pNumber;
	}
	
	public void setAddress(String addr) {
		if(addr == null || addr.length()>30) {
			throw new IllegalArgumentException("Invalid address");
		}
		this.address = addr;
	}
	
	
	
}