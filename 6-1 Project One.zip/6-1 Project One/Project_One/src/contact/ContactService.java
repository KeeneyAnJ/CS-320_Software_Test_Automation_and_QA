/*
 * Andrew Keeney
 * 11/27/2023
 * 6-1 Project One
 * CS-320
 */

package contact;

import java.util.ArrayList;

public class ContactService {
	
	public static ArrayList<Contact> contactList = new ArrayList<Contact>();

	// Function to add a contact with a unique contact ID. If contact ID is in use, output error message.
	public static boolean addContact(String contactId, String firstName, String lastName, String number, String address) {
		for (Contact Contact : contactList) {
			if(Contact.getContactId() == contactId) {
				System.out.println("Contact ID Is Not Unique");
				return false;
			}
		}
		Contact newContact = new Contact(contactId, firstName, lastName, number, address);
		contactList.add(newContact);
		System.out.println("New Contact Has Been Added");
		return true;
	}
	
	// Function to delete contact from contact list
	public static boolean deleteContact(String contactId) {
		for (Contact Contact : contactList) {
			if(Contact.getContactId() == contactId) {
				contactList.remove(Contact);
				System.out.println("Contact Has Been Removed");
				return true;
			}
		}
		return false;
	}
		
	// Function to modify first name given a contactId
	public static boolean modifyFirstName(String contactId, String firstName) {
		for (Contact Contact : contactList) {
			if(Contact.getContactId() == contactId) {
				Contact.setFirstName(firstName);
				System.out.println("Contact's First Name Has Been Updated");
				return true;
			}
		}
		System.out.println("ContactId Not Found");
		return false;
	}
		
	// Function to modify last name given a contactId
	public static boolean modifyLastName(String contactId, String lastName) {
		for (Contact Contact : contactList) {
			if(Contact.getContactId() == contactId) {
				Contact.setLastName(lastName);
				System.out.println("Contact's Last Name Has Been Updated");
				return true;
			}
		}
		System.out.println("ContactId Not Found");
		return false;
	}
	
	// Function to modify phone number given a contactId
	public static boolean modifyPhone(String contactId, String phone) {
		for (Contact Contact : contactList) {
			if(Contact.getContactId() == contactId) {
				Contact.setPhone(phone);
				System.out.println("Contact's Phone Number Has Been Updated");
				return true;
			}
		}
		System.out.println("ContactId Not Found");
		return false;
	}

	// Function to modify address given a contactId
	public static boolean modifyAddress(String contactId, String address) {
		for (Contact Contact : contactList) {
			if(Contact.getContactId() == contactId) {
				Contact.setAddress(address);
				System.out.println("Contact's Address Has Been Updated");
				return true;
			}
		}
		System.out.println("ContactId Not Found");
		return false;
	}
}