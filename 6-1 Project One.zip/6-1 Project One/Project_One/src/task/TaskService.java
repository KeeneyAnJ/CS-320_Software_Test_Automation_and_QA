/*
 * Andrew Keeney
 * 11/27/2023
 * 6-1 Project One
 * CS-320
 */

package task;

import java.util.ArrayList;

public class TaskService {
	
	public static ArrayList<Task> taskList = new ArrayList<Task>();
	
	// Function to add a task with a unique task ID. If task ID is in use, output error message.
	public static boolean addTask(String taskId, String name, String description) {
		for (Task Task : taskList) {
			if(Task.getTaskId() == taskId) {
				System.out.println("Task ID Is Not Unique");
				return false;
			}
		}
		Task newTask = new Task(taskId, name, description);
		taskList.add(newTask);
		System.out.println("New Task Has Been Added");
		return true;
	}

	// Function to delete task from task list
	public static boolean deleteTask(String taskId) {
		for (Task Task : taskList) {
			if(Task.getTaskId() == taskId) {
				taskList.remove(Task);
				System.out.println("Task Has Been Removed");
				return true;
			}
		}
		return false;
	}
		
	// Function to modify name given a taskId
	public static boolean modifyName(String taskId, String name) {
		for (Task Task : taskList) {
			if(Task.getTaskId() == taskId) {
				Task.setName(name);
				System.out.println("Task's Name Has Been Updated");
				return true;
			}
		}
		System.out.println("TaskId Not Found");
		return false;
	}

	// Function to modify description given a taskId
	public static boolean modifyDescription(String taskId, String description) {
		for (Task Task : taskList) {
			if(Task.getTaskId() == taskId) {
				Task.setDescription(description);
				System.out.println("Task's Description Has Been Updated");
				return true;
			}
		}
		System.out.println("TaskId Not Found");
		return false;
	}
}
