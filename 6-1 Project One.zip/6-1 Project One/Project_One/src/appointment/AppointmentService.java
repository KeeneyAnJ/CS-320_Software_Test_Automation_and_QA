/*
 * Andrew Keeney
 * 11/27/2023
 * 6-1 Project One
 * CS-320
 */

package appointment;

import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {
	
	public static ArrayList<Appointment> appointmentList = new ArrayList<Appointment>();
	
	// Function to add a appointment with a unique appointment ID. If appointment ID is in use, output error message.
	public static boolean addAppointment(String appointmentId, Date appointmentDate, String description) {
		for (Appointment Appointment : appointmentList) {
			if(Appointment.getAppointmentId() == appointmentId) {
				System.out.println("Appointment ID Is Not Unique");
				return false;
			}
		}
		Appointment newAppointment = new Appointment(appointmentId, appointmentDate, description);
		appointmentList.add(newAppointment);
		System.out.println("New Appointment Has Been Added");
		return true;
	}

	// Function to delete appointment from appointment list
	public static boolean deleteAppointment(String appointmentId) {
		for (Appointment Appointment : appointmentList) {
			if(Appointment.getAppointmentId() == appointmentId) {
				appointmentList.remove(Appointment);
				System.out.println("Appointment Has Been Removed");
				return true;
			}
		}
		System.out.println("AssignmentId Not Found");
		return false;
	}
}