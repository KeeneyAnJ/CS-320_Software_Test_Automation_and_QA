/*
 * Andrew Keeney
 * 11/27/2023
 * 6-1 Project One
 * CS-320
 */
package taskTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

//import contact.Contact;
import task.TaskService;

@DisplayName("TaskService Class Test")
public class TaskServiceTest {

	@Test
	@Order(1)
	void testAddingUniqueTaskId() {
		TaskService taskService = new TaskService();
		assertEquals(true, taskService.addTask("1", "task01", "Some Task"));
	}
	@Test
	@Order (2)
	void testAddingNonUniqueTaskId() {
		TaskService taskService = new TaskService();
		taskService.addTask("2", "task02", "Another Task");
		//taskService.printContactList();
		assertEquals(false, taskService.addTask("2", "task02", "Another Task"));
	}
	@Test
	@Order(3)
	void testDeletingTask() {
		TaskService taskService = new TaskService();
		taskService.addTask("3", "task01", "Some Task");
		assertEquals(true, taskService.deleteTask("3"));
	}
	@Test
	@Order(4)
	void testModifyingName() {
		TaskService taskService = new TaskService();
		taskService.addTask("4", "task01", "Some Task");
		assertEquals(true, taskService.modifyName("4", "task02"));
	}
	
	@Test
	@Order(5)
	void testModifyingDescription() {
		TaskService taskService = new TaskService();
		taskService.addTask("5", "task01", "Some Task");
		assertEquals(true, taskService.modifyDescription("5", "Another Task"));
	}
	
	@Test
	@Order(6)
	void testDeleting_TaskNotFound() {
		TaskService taskService = new TaskService();
		taskService.addTask("6", "task01", "Some Task");
		//taskService.printContactList();
		assertEquals(false, taskService.deleteTask("60"));
	}
	@Test
	@Order(7)
	void testModifyingName_TaskNotFound() {
		TaskService taskService = new TaskService();
		taskService.addTask("7", "task01", "Some Task");
		assertEquals(false, taskService.modifyName("70", "Task02"));
	}
	
	@Test
	@Order(8)
	void testModifyingDescription_TaskNotFound() {
		TaskService taskService = new TaskService();
		taskService.addTask("8", "task01", "Some Task");
		assertEquals(false, taskService.modifyDescription("80", "Another task"));
	}

}
