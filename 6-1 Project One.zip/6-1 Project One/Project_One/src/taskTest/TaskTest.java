/*
 * Andrew Keeney
 * 11/27/2023
 * 6-1 Project One
 * CS-320
 */
package taskTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import task.Task;

@DisplayName("Task Class Test")
class TaskTest {

	@DisplayName("Test to validate task object creation")
	@Test
	void testTaskClass() {
		Task task = new Task("1", "task01", "Some Task");
		assertTrue(task.getTaskId().equals("1"));
		assertTrue(task.getName().equals("task01"));
		assertTrue(task.getDescription().equals("Some Task"));
	}
	
	@DisplayName("Test to validate Updating Tasks Name and Description")
	@Test
	void testSetNameAndDescription() {
		Task task = new Task("1", "task01", "Some Task");
		task.setName("task02");
		task.setDescription("Another Task");
		assertTrue(task.getName().equals("task02"));
		assertTrue(task.getDescription().equals("Another Task"));
	}
	
	@DisplayName("TaskID greater than 10 char test")
	@Test
	void testTaskClassTaskIdToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345678910", "Task 01", "Some Task" );
		});
	}
	
	@DisplayName("Name greater than 20 char test")
	@Test
	void testTaskClassNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task("1", "Taskie McTask Task 01", "Some Task");
		});
	}
	
	@DisplayName("Description greater than 50 char test")
	@Test
	void testTaskClassDescriptionToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task("1", "task01", "This task is a task that tasks all other tasks. When completing this task, please task yourself with a task.");
		});
	}
	
	@DisplayName("TaskID is NULL test")
	@Test
	void testTaskClassTaskIdIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task(null, "task01", "Some Task");
		});
	}
	
	@DisplayName("Name is NULL test")
	@Test
	void testTaskClassNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task("1", null, "Some Task");
		});
	}
	
	@DisplayName("Description is NULL test")
	@Test
	void testTaskClassDesciptionIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task("1", "task01", null);
		});
	}
	
	@DisplayName("Setting Name greater that 20 char test")
	@Test
	void testTaskClassSetNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("1", "task01", "Some Task");
			task.setName("Taskie McTask Task 01");
		});
	}
	
	@DisplayName("Setting Name NULL test")
	@Test
	void testTaskClassSetNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("1", "task01", "Some Task");
			task.setName(null);
		});
	}
	
	@DisplayName("Setting description greater than 50 char test")
	@Test
	void testTaskClassSetdescriptionToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("1", "task01", "Some Task");
			task.setDescription("This task is a task that tasks all other tasks. When completing this task, please task yourself with a task.\"");
		});
	}
	
	@DisplayName("Setting description to NULL test")
	@Test
	void testTaskClassSetdescriptionNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("1", "task01", "Some Task");
			task.setDescription(null);
		});
	}
}