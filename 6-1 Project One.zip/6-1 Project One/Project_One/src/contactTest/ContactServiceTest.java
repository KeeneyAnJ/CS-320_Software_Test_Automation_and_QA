/*
 * Andrew Keeney
 * 11/27/2023
 * 6-1 Project One
 * CS-320
 */

package contactTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

//import contact.Contact;
import contact.ContactService;

@DisplayName("ContactService Class Test")
public class ContactServiceTest {

	@Test
	@Order(1)
	void testAddingUniqueContact() {
		ContactService contactService = new ContactService();
		assertEquals(true, contactService.addContact("1", "Jane", "Doe", "1234567890", "1 Main Street"));
	}
	@Test
	@Order (2)
	void testAddingNonUniqueContact() {
		ContactService contactService = new ContactService();
		contactService.addContact("7", "Jane", "Doe", "1234567890", "1 Main Street");
		//contactService.printContactList();
		assertEquals(false, contactService.addContact("7", "Jane", "Doe", "1234567890", "1 Main Street"));
	}
	@Test
	@Order(3)
	void testDeletingContact() {
		ContactService contactService = new ContactService();
		contactService.addContact("2", "Jane", "Doe", "1234567890", "1 Main Street");
		assertEquals(true, contactService.deleteContact("2"));
	}
	@Test
	@Order(4)
	void testModifyingContactFirstName() {
		ContactService contactService = new ContactService();
		contactService.addContact("3", "Jane", "Doe", "1234567890", "1 Main Street");
		assertEquals(true, contactService.modifyFirstName("3", "John"));
	}
	@Test
	@Order(5)
	void testModifyingContactLastName() {
		ContactService contactService = new ContactService();
		contactService.addContact("4", "Jane", "Doe", "1234567890", "1 Main Street");
		assertEquals(true, contactService.modifyLastName("4", "Smith"));
	}
	@Test
	@Order(6)
	void testModifyingContactPhone() {
		ContactService contactService = new ContactService();
		contactService.addContact("5", "Jane", "Doe", "1234567890", "1 Main Street");
		assertEquals(true, contactService.modifyPhone("5", "0987654321"));
	}
	@Test
	@Order(7)
	void testModifyingAddress() {
		ContactService contactService = new ContactService();
		contactService.addContact("6", "Jane", "Doe", "1234567890", "1 Main Street");
		assertEquals(true, contactService.modifyAddress("6", "2 Elm Street"));
	}
	
	@Test
	@Order(8)
	void testDeletingContactNotFound() {
		ContactService contactService = new ContactService();
		contactService.addContact("8", "Jane", "Doe", "1234567890", "1 Main Street");
		//contactService.printContactList();
		assertEquals(false, contactService.deleteContact("80"));
	}
	@Test
	@Order(9)
	void testModifyingFirstNameContactNotFound() {
		ContactService contactService = new ContactService();
		contactService.addContact("3", "Jane", "Doe", "1234567890", "1 Main Street");
		assertEquals(false, contactService.modifyFirstName("30", "John"));
	}
	@Test
	@Order(10)
	void testModifyingLastNameContactNotFound() {
		ContactService contactService = new ContactService();
		contactService.addContact("4", "Jane", "Doe", "1234567890", "1 Main Street");
		assertEquals(false, contactService.modifyLastName("40", "Smith"));
	}
	@Test
	@Order(11)
	void testModifyingPhoneContactNotFound() {
		ContactService contactService = new ContactService();
		contactService.addContact("5", "Jane", "Doe", "1234567890", "1 Main Street");
		assertEquals(false, contactService.modifyPhone("50", "0987654321"));
	}
	@Test
	@Order(12)
	void testModifyingAddressContactNotFound() {
		ContactService contactService = new ContactService();
		contactService.addContact("6", "Jane", "Doe", "1234567890", "1 Main Street");
		assertEquals(false, contactService.modifyAddress("60", "2 Elm Street"));
	}

}
