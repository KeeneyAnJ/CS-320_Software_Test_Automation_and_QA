/*
 * Andrew Keeney
 * 11/27/2023
 * 6-1 Project One
 * CS-320
 */
package contactTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import contact.Contact;

@DisplayName("Contact Class Test")
class ContactTest {

	@DisplayName("Test to validate contact object creation")
	@Test
	void testContactClass() {
		Contact contact = new Contact("contact 01",
				"John", "Doe", "1234567890", "1 Main Street" );
		assertTrue(contact.getContactId().equals("contact 01"));
		assertTrue(contact.getFirstName().equals("John"));
		assertTrue(contact.getLastName().equals("Doe"));
		assertTrue(contact.getPhone().equals("1234567890"));
		assertTrue(contact.getAddress().equals("1 Main Street"));
	}
	
	@DisplayName("Test to validate Updating Contacts First, Last, Phone, Address")
	@Test
	void testSetFirstName() {
		Contact contact = new Contact("contact 01",
				"John", "Doe", "1234567890", "1 Main Street" );
		contact.setFirstName("George");
		contact.setLastName("Pickles");
		contact.setPhone("8008675309");
		contact.setAddress("100 Elm Street");
		assertTrue(contact.getFirstName().equals("George"));
		assertTrue(contact.getLastName().equals("Pickles"));
		assertTrue(contact.getPhone().equals("8008675309"));
		assertTrue(contact.getAddress().equals("100 Elm Street"));
	}
	
	@DisplayName("ContactID greater that 10 char test")
	@Test
	void testContactClassContactIdToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Contact 999", "John", "Doe", "1234567890", "1 Main Street" );
		});
	}
	
	@DisplayName("First Name greater than 10 char test")
	@Test
	void testContactClassFirstNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("Contact 01", "Johnnnnnnny", "Doe", "1234567890", "1 Main Street" );
		});
	}
	
	@DisplayName("Last Name greater than 10 char test")
	@Test
	void testContactClassLastNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("Contact 01", "John", "Deutschmacher", "1234567890", "1 Main Street" );
		});
	}
	
	@DisplayName("Phone Number less than 10 char test")
	@Test
	void testContactClassNumberToShort() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("Contact 01", "John", "Doe", "123456789", "1 Main Street" );
		});
	}
	
	@DisplayName("Phone Number greater than 10 char test")
	@Test
	void testContactClassNumberToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("Contact 01", "John", "Doe", "12345678911", "1 Main Street" );
		});
	}
	
	@DisplayName("Address greater than 30 char test")
	@Test
	void testContactClassAddressToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("Contact 01", "John", "Doe", "1234567890", "8675309 Bartholomew Jr. Boulevard" );
		});
	}
	
	@DisplayName("ContactID is NULL test")
	@Test
	void testContactClassContactIdIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact(null, "John", "Doe", "1234567890", "1 Main Street" );
		});
	}
	
	@DisplayName("First Name is NULL test")
	@Test
	void testContactClassFirstNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("Contact 01", null, "Doe", "1234567890", "1 Main Street" );
		});
	}
	@DisplayName("Last Name is NULL test")
	@Test
	void testContactClassLastNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("Contact 01", "John", null, "1234567890", "1 Main Street" );
		});
	}
	
	@DisplayName("Phone Number is NULL test")
	@Test
	void testContactClassNumberIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("Contact 01", "John", "Doe", null, "1 Main Street" );
		});
	}
	
	@DisplayName("Address is NULL test")
	@Test
	void testContactClassAddressIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("Contact 01", "John", "Doe", "1234567890", null );
		});
	}
	
	@DisplayName("Setting Fisrt Name greater that 10 char test")
	@Test
	void testContactClassSetFirstNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("contact 01",
					"John", "Doe", "1234567890", "1 Main Street" );
			contact.setFirstName("Jimmmmmmmmmmmmmmmy");
		});
	}
	
	@DisplayName("Setting Fisrt Name NULL test")
	@Test
	void testContactClassSetFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("contact 01",
					"John", "Doe", "1234567890", "1 Main Street" );
			contact.setFirstName(null);
		});
	}
	
	@DisplayName("Setting Last Name greater that 10 char test")
	@Test
	void testContactClassSetLastNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("contact 01",
					"John", "Doe", "1234567890", "1 Main Street" );
			contact.setLastName("Doeeeeeeeeeeeeee");
		});
	}
	
	@DisplayName("Setting Last Name NULL test")
	@Test
	void testContactClassSetLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("contact 01",
					"John", "Doe", "1234567890", "1 Main Street" );
			contact.setLastName(null);
		});
	}
	
	@DisplayName("Setting Address greater that 30 char test")
	@Test
	void testContactClassSetAddressToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("contact 01",
					"John", "Doe", "1234567890", "1 Main Street" );
			contact.setAddress("8675309 Bartholomew Jr. Boulevard");
		});
	}
	
	@DisplayName("Setting Address to NULL test")
	@Test
	void testContactClassSetAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("contact 01",
					"John", "Doe", "1234567890", "1 Main Street" );
			contact.setAddress(null);
		});
	}
	
	@DisplayName("Setting Phone number greater that 10 char test")
	@Test
	void testContactClassSetPhoneToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("contact 01",
					"John", "Doe", "1234567890", "1 Main Street" );
			contact.setPhone("1234567891011");
		});
	}
	@DisplayName("Setting Phone number less that 10 char test")
	@Test
	void testContactClassSetPhoneToShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("contact 01",
					"John", "Doe", "1234567890", "1 Main Street" );
			contact.setPhone("123456789");
		});
	}
	
	@DisplayName("Setting Phone Number to NULL test")
	@Test
	void testContactClassSetPhoneNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("contact 01",
					"John", "Doe", "1234567890", "1 Main Street" );
			contact.setPhone(null);
		});
	}
	
}