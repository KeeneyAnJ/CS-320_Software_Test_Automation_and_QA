/*
 * Andrew Keeney
 * 11/27/2023
 * 6-1 Project One
 * CS-320
 */
package appointmentTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import appointment.Appointment;
import java.util.Date;

@DisplayName("Appointment Class Test")
class AppointmentTest {

	@DisplayName("Test to validate appointment object creation")
	@Test
	void testAppointmentClass() {
		Date dateCompare = new Date(124,1,1); //date format: (year minus 1900, month, year)
		Appointment appointment = new Appointment("1", new Date(124,1,1), "Some Appointment");
		assertTrue(appointment.getAppointmentId().equals("1"));
		assertTrue(appointment.getAppointmentDate().equals(dateCompare));
		assertTrue(appointment.getDescription().equals("Some Appointment"));
	}
	
	@DisplayName("AppointmentID greater than 10 char test")
	@Test
	void testAppointmentClassAppointmentIdToLong() {
		Date date = new Date(124,1,1);    //date format: (year minus 1900, month, year)
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345678910", date, "Some Appointment" );
		});
	}
	
	@DisplayName("Date in the past test")
	@Test
	void testAppointmentClassDateInPast() {
		Date pastDate = new Date(123,1,1); //date format: (year minus 1900, month, year)
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Appointment("1", pastDate, "Some Appointment");
		});
	}
	
	@DisplayName("Description greater than 50 char test")
	@Test
	void testAppointmentClassDescriptionToLong() {
		Date date = new Date(124,1,1); //date format: (year minus 1900, month, year)
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Appointment("1", date, "This appointment is a appointment that appointments all other appointments. When completing this appointment, please appointment yourself with a appointment.");
		});
	}
	
	@DisplayName("AppointmentID is NULL test")
	@Test
	void testAppointmentClassAppointmentIdIsNull() {
		Date date = new Date(124,1,1); //date format: (year minus 1900, month, year)
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Appointment(null, date, "Some Appointment");
		});
	}
	
	@DisplayName("Date is NULL test")
	@Test
	void testAppointmentClassDateIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Appointment("1", null, "Some Appointment");
		});
	}
	
	@DisplayName("Description is NULL test")
	@Test
	void testAppointmentClassDesciptionIsNull() {
		Date date = new Date(124,1,1); //date format: (year minus 1900, month, year)
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Appointment("1", date, null);
		});
	}
}
