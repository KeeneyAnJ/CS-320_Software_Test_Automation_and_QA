/*
 * Andrew Keeney
 * 11/27/2023
 * 6-1 Project One
 * CS-320
 */

package appointmentTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import java.util.Date;

//import contact.Contact;
import appointment.AppointmentService;

@DisplayName("AppointmentService Class Test")
public class AppointmentServiceTest {

	@Test
	@Order(1)
	void testAddingUniqueAppointmentId() {
		Date date = new Date(124,1,1);  //date format: (year minus 1900, month, year)
		AppointmentService appointmentService = new AppointmentService();
		assertEquals(true, appointmentService.addAppointment("1", date, "Some Appointment"));
	}
	@Test
	@Order (2)
	void testAddingNonUniqueAppointmentId() {
		Date date = new Date(124,1,1);  //date format: (year minus 1900, month, year)
		AppointmentService appointmentService = new AppointmentService();
		appointmentService.addAppointment("2", new Date(), "Another Appointment");
		//appointmentService.printContactList();
		assertEquals(false, appointmentService.addAppointment("2", date, "Another Appointment"));
	}
	@Test
	@Order(3)
	void testDeletingAppointment() {
		Date date = new Date(124,1,1);  //date format: (year minus 1900, month, year)
		AppointmentService appointmentService = new AppointmentService();
		appointmentService.addAppointment("3", date, "Some Appointment");
		assertEquals(true, appointmentService.deleteAppointment("3"));
	}
	
	@Test
	@Order(4)
	void testDeleting_AppointmentNotFound() {
		Date date = new Date(124,1,1);  //date format: (year minus 1900, month, year)
		AppointmentService appointmentService = new AppointmentService();
		appointmentService.addAppointment("4", date, "Some Appointment");
		//appointmentService.printContactList();
		assertEquals(false, appointmentService.deleteAppointment("40"));
	}
	

}
